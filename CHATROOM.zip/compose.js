
var msg = 'hello *i am a* pedophile';

var mySubString = str.substring(
  var str = 'one:two;three';
  nonbold1 = msg.split('{')[0]
  boldbit = msg.split('{')[1].split('}')[0]
  nonbold2 = msg.split('{')[1].split('}')[1]

  newmessage = nonbold1+boldbit+nonbold2
);